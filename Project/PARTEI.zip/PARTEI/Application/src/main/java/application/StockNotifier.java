package application;

import framework.annotation.Async;
import framework.annotation.EventListener;
import framework.annotation.Service;

@Service
public class StockNotifier {
    @EventListener
    @Async
    public void handleChangeEvent(StockChangeEvent stockChangeEvent) {

        System.out.printf("StockNotifier received event :%s\n" ,stockChangeEvent.toString());;
    }
}


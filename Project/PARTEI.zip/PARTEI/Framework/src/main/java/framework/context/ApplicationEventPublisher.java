package framework.context;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

@FunctionalInterface
public interface ApplicationEventPublisher {
    List<Event> eventListeners = new ArrayList<>();

    default void publishEvent(ApplicationEvent event) throws InvocationTargetException, IllegalAccessException {
        this.publishEvent((Object) event);
    }

    void publishEvent(Object event) throws InvocationTargetException, IllegalAccessException;

    default void addListener(Event eventListener) {
        eventListeners.add(eventListener);
    }
}

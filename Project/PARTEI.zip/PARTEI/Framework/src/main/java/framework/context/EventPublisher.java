package framework.context;

import framework.annotation.Async;
import framework.annotation.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

@Service
public class EventPublisher implements ApplicationEventPublisher {
    @Override
    public void publishEvent(Object event) throws InvocationTargetException, IllegalAccessException {
        for (Event ev : eventListeners) {
            if(ev.getMethod().isAnnotationPresent(Async.class) && ev.isAsyncEnabled())
            {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            ev.getMethod().invoke(ev.getObserver(), event);
                        } catch (IllegalAccessException e) {
                            throw new RuntimeException(e);
                        } catch (InvocationTargetException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }).start();

            }
            else
            {
                ev.getMethod().invoke(ev.getObserver(), event);
            }

        }
    }
}

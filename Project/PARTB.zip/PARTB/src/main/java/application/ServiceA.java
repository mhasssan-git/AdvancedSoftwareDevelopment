package application;

public interface ServiceA {
    void methodA();
}

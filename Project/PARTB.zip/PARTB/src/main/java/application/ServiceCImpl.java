package application;

import framework.annotation.Service;

@Service("ServiceC1")
public class ServiceCImpl implements ServiceC{
    @Override
    public void methodC() {
        System.out.println("Print from service C 1");
    }
}

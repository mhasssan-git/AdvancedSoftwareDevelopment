package framework.context;

import framework.annotation.Autowired;
import framework.annotation.Qualifier;
import framework.annotation.Service;
import org.reflections.Reflections;

import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

public class ApplicationContext {
    private static List<Object> serviceObjectMap = new ArrayList<>();
    Reflections reflections = new Reflections("");

    public ApplicationContext() {
        try {

            Set<Class<?>> serviceTypes = reflections.getTypesAnnotatedWith(Service.class);
            Set<Class<?>> paramLessServiceTypes = serviceTypes.stream().filter(a -> {
                Constructor[] constructors = a.getDeclaredConstructors();
                if (Arrays.stream(constructors).filter(b -> b.getParameterTypes().length > 0).findFirst().isPresent()) {
                    return false;
                }
                return true;
            }).collect(Collectors.toSet());
            for (Class<?> serviceType : paramLessServiceTypes) {

                Object instance = null;
                instance = (Object) serviceType.newInstance();
                serviceObjectMap.add(instance);
            }
            Set<Class<?>> diServiceTypes = serviceTypes.stream().filter(a -> {
                Constructor[] constructors = a.getDeclaredConstructors();
                if (Arrays.stream(constructors).filter(b -> b.getParameterTypes().length > 0).findFirst().isPresent()) {
                    return true;
                }
                return false;
            }).collect(Collectors.toSet());

            for (Class<?> serviceType : diServiceTypes) {

                performConstructorDI(serviceType);
            }
            performDI();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void performConstructorDI(Class<?> serviceType) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Constructor[] constructors = serviceType.getConstructors();
        Constructor constructor = constructors[0];
        Object instance = null;
        if (constructor != null) {
            if (constructor.isAnnotationPresent(Autowired.class)) {
                List<Object> paramObj = new ArrayList<>();
                Class<?>[] params = constructor.getParameterTypes();
                for (Class<?> param : params) {
                    Object paramInstance = getServiceBeanOfType(param);
                    if (paramInstance == null) {
                        Class<?> cls = findClass(param);
                        performConstructorDI(cls);

                    }
                    paramObj.add(getServiceBeanOfType(param));
                }
                instance = constructor.newInstance(paramObj.toArray());
            } else {
                instance = serviceType.newInstance();
            }
        } else {
            instance = serviceType.newInstance();
        }
        serviceObjectMap.add(instance);
    }

    private Class<?> findClass(Class<?> inf) {
        Set<Class<?>> serviceTypes = reflections.getTypesAnnotatedWith(Service.class);
        for (Class<?> serviceType : serviceTypes) {
            Class<?>[] interfaces = serviceType.getInterfaces();
            for (Class<?> theInterface : interfaces) {
                if (theInterface.getName().contentEquals(inf.getName())) {
                    return serviceType;
                }
            }
        }
        return null;
    }

    private void performDI() throws IllegalAccessException, InvocationTargetException {
        ///////// Field  injection : Part A
        for (Object serviceClass : serviceObjectMap) {
            for (Field field : serviceClass.getClass().getDeclaredFields()) {
                if (field.isAnnotationPresent(Autowired.class)) {

                    Object instance = null;
                    if (field.isAnnotationPresent(Qualifier.class)) {
                        String name = field.getAnnotation(Qualifier.class).value();
                        instance = getServiceBeanOfName(name);
                    } else {
                        Class<?> theFieldType = field.getType();
                        instance = getServiceBeanOfType(theFieldType);
                    }
                    field.setAccessible(true);
                    field.set(serviceClass, instance);
                }
            }
        }
        ///////// Setter injection Part B
        for (Object serviceClass : serviceObjectMap) {
            for (Method method : serviceClass.getClass().getDeclaredMethods()) {
                if (method.isAnnotationPresent(Autowired.class) && method.getName().startsWith("set")) {
                    Parameter[] params = method.getParameters();
                    Class<?> paramType = params[0].getType();
                    Object instance = getServiceBeanOfType(paramType);
                    method.invoke(serviceClass, instance);
                }
            }
        }
    }

    private Object getServiceBeanOfType(Class interfaceClass) {
        Object service = null;
        for (Object cls : serviceObjectMap) {
            Class<?>[] interfaces = cls.getClass().getInterfaces();
            for (Class<?> a : interfaces) {
                if (a.getName().contentEquals(interfaceClass.getName())) {
                    service = cls;
                }
            }
            ;
        }
        return service;
    }

    private Object getServiceBeanOfName(String name) {
        Object service = null;
        for (Object cls : serviceObjectMap) {
            if (cls.getClass().getAnnotation(Service.class).value().equals(name)) {
                service = cls;
            }
        }
        return service;
    }

    public Object getBean(String beanName, Class interfaceClass) {
        if (beanName == "")
            return getServiceBeanOfType(interfaceClass);
        else return getServiceBeanOfName(beanName);
    }
}

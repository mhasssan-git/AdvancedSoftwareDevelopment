package application;

public interface ServiceC {
    void methodC();
}

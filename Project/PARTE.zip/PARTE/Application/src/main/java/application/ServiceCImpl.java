package application;

import framework.annotation.Profile;
import framework.annotation.Service;

@Service("ServiceC1")
@Profile("serviceC")
public class ServiceCImpl implements ServiceC{
    @Override
    public void methodC() {
        System.out.println("Print from service C 1");
    }
}

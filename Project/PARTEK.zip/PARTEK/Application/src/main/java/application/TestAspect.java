package application;

import framework.annotation.After;
import framework.annotation.Aspect;
import framework.annotation.Before;
import framework.annotation.Service;

@Aspect
@Service
public class TestAspect {
    @Before(pointcut = "application.StockService.changeStockValue")
    public void testMethod(){
        System.out.println("Before Execute");
    }
    @After(pointcut = "application.StockService.changeStockValue")
    public void testMethod2(){
        System.out.println("After Execute");
    }
}

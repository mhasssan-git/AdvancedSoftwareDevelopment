package application;

public interface ServiceB {
    void methodB();
}

package application;

import framework.context.ApplicationContext;

public class Application {
    public static void main(String[] args) {
        ApplicationContext context = new ApplicationContext();
        ServiceA serviceA = (ServiceA) context.getBean("", ServiceA.class);
        serviceA.methodA();

        System.out.println("Print from service A: " + serviceA.getPropA());
        System.out.println("Print from service A: " + serviceA.getPropB());
    }
}

package application;

public interface StockService {
    public void changeStockValue(String stockName, double value);
}

package application;

public class StockChangeEvent {
    private String stockName;
    private double newValue;
    public StockChangeEvent(String stockName, double newValue) {
        this.stockName = stockName;
        this.newValue = newValue;
    }
    @Override
    public String toString() {
        return "StockChangeEvent [stockName=" + stockName + ", newValue=" + newValue + "]";
    }
}
package application;

import framework.annotation.Autowired;
import framework.annotation.EnableAsync;
import framework.annotation.EnableScheduling;
import framework.annotation.SpringBootApplication;
import framework.context.ApplicationContext;
import javassist.NotFoundException;
import javassist.bytecode.DuplicateMemberException;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

@SpringBootApplication
@EnableScheduling
public class Application implements Runnable {
    @Autowired
    private StockService stockService;

    public static void main(String[] args) throws InstantiationException, IllegalAccessException, IOException, InvocationTargetException, DuplicateMemberException, NotFoundException, ClassNotFoundException, NoSuchMethodException {
        ApplicationContext.run(Application.class);
    }

    @Override
    public void run() {
        try {
            stockService.changeStockValue("AMZN", 2310.80);
            stockService.changeStockValue("MSFT", 890.45);
        } catch (Exception ex) {

        }

    }
}

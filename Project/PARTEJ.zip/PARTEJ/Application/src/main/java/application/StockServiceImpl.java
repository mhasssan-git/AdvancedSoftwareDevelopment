package application;

import framework.annotation.Autowired;
import framework.annotation.Service;
import framework.context.ApplicationEventPublisher;

import java.lang.reflect.InvocationTargetException;

@Service
public class StockServiceImpl implements StockService {
    @Autowired
    private ApplicationEventPublisher publisher;
    public void changeStockValue(String stockName, double value) {
        /*
        try {
            publisher.publishEvent(new StockChangeEvent(stockName, value));
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        */
         System.out.println("Stock Changed");
    }
}


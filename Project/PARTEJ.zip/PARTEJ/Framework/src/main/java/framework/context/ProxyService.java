package framework.context;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class ProxyService implements InvocationHandler {
    public ProxyService(Object target, Method method, PointCutType pointCutType) {
        this.target = target;
        this.method = method;
        this.pointCutType = pointCutType;
    }

    private Object target;
    private Method method;
    private  PointCutType pointCutType;
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
       Object returnValue=method.invoke(target,args);
       System.out.println("Aspect calling");
       return returnValue;
    }
}

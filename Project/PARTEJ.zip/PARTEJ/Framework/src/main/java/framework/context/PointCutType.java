package framework.context;

public enum PointCutType {
    BEFORE,AFTER
}

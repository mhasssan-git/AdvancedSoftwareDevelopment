package framework.context;

import framework.annotation.Autowired;
import framework.annotation.Service;
import org.reflections.Reflections;

import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

public class ApplicationContext {
    private static List<Object> serviceObjectMap = new ArrayList<>();
    Reflections reflections = new Reflections("");
    public ApplicationContext() {
        try {

            Set<Class<?>> serviceTypes = reflections.getTypesAnnotatedWith(Service.class);

            for (Class<?> serviceType : serviceTypes) {
                Object instance = null;
                instance = (Object) serviceType.newInstance();
                serviceObjectMap.add(instance);
            }

            performDI();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private void performDI() throws IllegalAccessException, InvocationTargetException {
        for (Object serviceClass : serviceObjectMap) {
            for (Field field : serviceClass.getClass().getDeclaredFields()) {
                if (field.isAnnotationPresent(Autowired.class)) {
                    Class<?> theFieldType = field.getType();
                    Object instance = getServiceBeanOfType(theFieldType);
                    field.setAccessible(true);
                    field.set(serviceClass, instance);
                }
            }
        }

    }

    private Object getServiceBeanOfType(Class interfaceClass) {
        Object service = null;
        for (Object cls : serviceObjectMap) {
            Class<?>[] interfaces = cls.getClass().getInterfaces();
            for (Class<?> a : interfaces) {
                if (a.getName().contentEquals(interfaceClass.getName())) {
                    service = cls;
                }
            }
            ;
        }
        return service;
    }

    public Object getBean(Class interfaceClass) {
        return getServiceBeanOfType(interfaceClass);
    }


}

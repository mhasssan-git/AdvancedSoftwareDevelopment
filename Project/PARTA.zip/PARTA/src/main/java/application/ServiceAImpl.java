package application;

import framework.annotation.Autowired;
import framework.annotation.Service;

@Service
public class ServiceAImpl implements ServiceA {
    @Autowired
    private ServiceB serviceB;
    @Override
    public void methodA() {
        System.out.println("Print from service A");
        serviceB.methodB();
    }
}

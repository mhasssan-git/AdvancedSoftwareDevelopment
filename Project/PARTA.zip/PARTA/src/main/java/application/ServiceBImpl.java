package application;

import framework.annotation.Autowired;
import framework.annotation.Service;

@Service
public class ServiceBImpl implements ServiceB{
    @Override
    public void methodB() {
        System.out.println("Print from service B");
    }
}

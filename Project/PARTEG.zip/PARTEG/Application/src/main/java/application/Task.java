package application;

import framework.annotation.Scheduled;
import framework.annotation.Service;

import java.security.PublicKey;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

@Service
public class Task {
    @Scheduled(cron = "5 0")
    public void method() {
        Date date= Calendar.getInstance().getTime();
        DateFormat timeFormatter=DateFormat.getTimeInstance(DateFormat.DEFAULT);
        String currentTime=timeFormatter.format(date);
        System.out.printf("This task runs at %s\n",currentTime);
    }
}

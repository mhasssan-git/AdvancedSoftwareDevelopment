package application;

public interface ServiceA {
    void methodA();
    String getPropA();
    String getPropB();
}

package application;

import framework.annotation.Profile;
import framework.annotation.Scheduled;
import framework.annotation.Service;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

@Service("ServiceC1")
@Profile("serviceC")
public class ServiceCImpl implements ServiceC{
    @Override
    public void methodC() {
        System.out.println("Print from service C 1");
    }
}

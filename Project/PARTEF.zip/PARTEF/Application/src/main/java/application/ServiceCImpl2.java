package application;

import framework.annotation.Profile;
import framework.annotation.Service;

@Service( "ServiceC2")
@Profile("serviceC2")
public class ServiceCImpl2 implements ServiceC{
    @Override
    public void methodC() {
        System.out.println("Print from service C 2");
    }
}

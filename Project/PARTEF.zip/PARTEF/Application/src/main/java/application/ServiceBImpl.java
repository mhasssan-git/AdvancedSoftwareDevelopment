package application;

import framework.annotation.Autowired;
import framework.annotation.Qualifier;
import framework.annotation.Service;

@Service
public class ServiceBImpl implements ServiceB {
    //@Autowired
    //public ServiceBImpl(ServiceC serviceC) {
    // this.serviceC = serviceC;
    //}
    @Autowired
    //@Qualifier("ServiceC1")
    ServiceC serviceC;

    @Override
    public void methodB() {
        serviceC.methodC();
        System.out.println("Print from service B");
    }
}

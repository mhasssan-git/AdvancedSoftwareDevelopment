package application;

import framework.annotation.Autowired;
import framework.annotation.Service;
import framework.annotation.Value;

@Service
public class ServiceAImpl implements ServiceA {

    @Autowired
    public ServiceAImpl(ServiceB serviceB) {
        this.serviceB = serviceB;
    }

    private ServiceB serviceB;

    public String getPropA() {
        return propA;
    }

    public String getPropB() {
        return propB;
    }

    @Value("${test}")
    private String propA;
    @Value("Hello World")
    private String propB;

    @Override
    public void methodA() {
        System.out.println("Print from service A");
        serviceB.methodB();
    }
}

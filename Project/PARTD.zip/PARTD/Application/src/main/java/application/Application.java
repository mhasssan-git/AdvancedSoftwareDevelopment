package application;

import framework.annotation.Autowired;
import framework.annotation.SpringBootApplication;
import framework.context.ApplicationContext;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

@SpringBootApplication
public class Application implements  Runnable{
    @Autowired
    ServiceA serviceA;
    public static void main(String[] args) throws InstantiationException, IllegalAccessException, IOException, InvocationTargetException {
        ApplicationContext.run(Application.class);
    }

    @Override
    public void run() {
        serviceA.methodA();
        System.out.println("Print from service A: " + serviceA.getPropA());
        System.out.println("Print from service A: " + serviceA.getPropB());
    }
}

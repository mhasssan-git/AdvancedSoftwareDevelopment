package framework.context;

import framework.annotation.*;
import org.reflections.Reflections;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ApplicationContext {
    private static List<Object> serviceObjectMap = new ArrayList<>();
    Reflections reflections = new Reflections("");

    private ApplicationContext() {
        try {

            Set<Class<?>> serviceTypes = reflections.getTypesAnnotatedWith(Service.class);
            Set<Class<?>> paramLessServiceTypes = serviceTypes.stream().filter(a -> {
                Constructor[] constructors = a.getDeclaredConstructors();
                if (Arrays.stream(constructors).filter(b -> b.getParameterTypes().length > 0).findFirst().isPresent()) {
                    return false;
                }
                return true;
            }).collect(Collectors.toSet());
            for (Class<?> serviceType : paramLessServiceTypes) {

                Object instance = null;
                instance = (Object) serviceType.newInstance();
                serviceObjectMap.add(instance);
            }
            Set<Class<?>> diServiceTypes = serviceTypes.stream().filter(a -> {
                Constructor[] constructors = a.getDeclaredConstructors();
                if (Arrays.stream(constructors).filter(b -> b.getParameterTypes().length > 0).findFirst().isPresent()) {
                    return true;
                }
                return false;
            }).collect(Collectors.toSet());

            for (Class<?> serviceType : diServiceTypes) {

                performConstructorDI(serviceType);
            }
            performDI();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void performConstructorDI(Class<?> serviceType) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Constructor[] constructors = serviceType.getConstructors();
        Constructor constructor = constructors[0];
        Object instance = null;
        if (constructor != null) {
            if (constructor.isAnnotationPresent(Autowired.class)) {
                List<Object> paramObj = new ArrayList<>();
                Class<?>[] params = constructor.getParameterTypes();
                for (Class<?> param : params) {
                    Object paramInstance = getServiceBeanOfType(param);
                    if (paramInstance == null) {
                        Class<?> cls = findClass(param);
                        performConstructorDI(cls);

                    }
                    paramObj.add(getServiceBeanOfType(param));
                }
                instance = constructor.newInstance(paramObj.toArray());
            } else {
                instance = serviceType.newInstance();
            }
        } else {
            instance = serviceType.newInstance();
        }
        serviceObjectMap.add(instance);
    }

    private Class<?> findClass(Class<?> inf) {
        Set<Class<?>> serviceTypes = reflections.getTypesAnnotatedWith(Service.class);
        for (Class<?> serviceType : serviceTypes) {
            Class<?>[] interfaces = serviceType.getInterfaces();
            for (Class<?> theInterface : interfaces) {
                if (theInterface.getName().contentEquals(inf.getName())) {
                    return serviceType;
                }
            }
        }
        return null;
    }

    private void performDI() throws IllegalAccessException, InvocationTargetException, IOException {
        for (Object serviceClass : serviceObjectMap) {
            ///////// Field  injection : Part A
            fieldInjection(serviceClass);
            ///////// Setter injection Part B
            setterInjection(serviceClass);
        }
    }

    private void setterInjection(Object serviceClass) throws IllegalAccessException, InvocationTargetException {
        for (Method method : serviceClass.getClass().getDeclaredMethods()) {
            if (method.isAnnotationPresent(Autowired.class) && method.getName().startsWith("set")) {
                Parameter[] params = method.getParameters();
                Class<?> paramType = params[0].getType();
                Object instance = getServiceBeanOfType(paramType);
                method.invoke(serviceClass, instance);
            }
        }
    }

    private void fieldInjection(Object serviceClass) throws IllegalAccessException, IOException {

        for (Field field : serviceClass.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(Autowired.class)) {

                Object instance = null;
                if (field.isAnnotationPresent(Qualifier.class)) {
                    String name = field.getAnnotation(Qualifier.class).value();
                    instance = getServiceBeanOfName(name);
                } else {
                    Class<?> theFieldType = field.getType();
                    instance = getServiceBeanOfType(theFieldType);
                }
                field.setAccessible(true);
                field.set(serviceClass, instance);
            } else if (field.isAnnotationPresent(Value.class)) {
                String value = field.getAnnotation(Value.class).value();
                Pattern pattern = Pattern.compile("\\$\\{.*?\\}");
                if (pattern.matcher(value).find()) {
                    String rootPath = Thread.currentThread().getContextClassLoader()
                            .getResource("").getPath();
                    Properties prop = new Properties();
                    prop.load(new FileInputStream(rootPath + "/config.properties"));
                    value = value.substring(2);
                    value = value.substring(0, value.length() - 1);
                    value = prop.getProperty(value);

                }
                field.setAccessible(true);
                field.set(serviceClass, value);
            }
        }
    }


    private Object getServiceBeanOfType(Class interfaceClass) {
        Object service = null;
        for (Object cls : serviceObjectMap) {
            Class<?>[] interfaces = cls.getClass().getInterfaces();
            for (Class<?> a : interfaces) {
                if (a.getName().contentEquals(interfaceClass.getName())) {
                    service = cls;
                }
            }
            ;
        }
        return service;
    }

    private Object getServiceBeanOfName(String name) {
        Object service = null;


        for (Object cls : serviceObjectMap) {
            String val=cls.getClass().getAnnotation(Service.class)!=null?cls.getClass().getAnnotation(Service.class).value():
                    cls.getClass().getAnnotation(SpringBootApplication.class).value();
            if (val.equals(name)) {
                service = cls;
            }
        }
        return service;
    }

    public Object getBean(String beanName, Class interfaceClass) {
        if (beanName == "")
            return getServiceBeanOfType(interfaceClass);
        else return getServiceBeanOfName(beanName);
    }

    public static void run(Class<?> application) throws InstantiationException, IllegalAccessException, IOException, InvocationTargetException {
        ApplicationContext context = new ApplicationContext();
        Object app = application.newInstance();
        serviceObjectMap.add(app);
        context.performDI();
        if (app.getClass().getSuperclass().isInstance(Runnable.class)) {
            ((Runnable) app).run();
        }
    }
}

package framework.context;

import java.lang.reflect.Method;

public class Event {
    private Method method;
    public Object getObserver() {
        return observer;
    }
    public Method getMethod() {
        return method;
    }



    private Object observer;

    public Event(Method method, Object event) {
        this.method = method;
        this.observer = event;
    }
}

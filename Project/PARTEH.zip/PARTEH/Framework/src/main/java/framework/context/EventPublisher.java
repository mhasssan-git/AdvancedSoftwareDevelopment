package framework.context;

import framework.annotation.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

@Service
public class EventPublisher implements ApplicationEventPublisher {
    @Override
    public void publishEvent(Object event) throws InvocationTargetException, IllegalAccessException {
        for (Event ev : eventListeners) {
            ev.getMethod().invoke(ev.getObserver(), event);
        }
    }
}

package application;

import framework.annotation.EventListener;
import framework.annotation.Service;

@Service
public class StockNotifier {
    @EventListener
    public void handleChangeEvent(StockChangeEvent stockChangeEvent) {

        System.out.printf("StockNotifier received event :%s\n" ,stockChangeEvent.toString());;
    }
}


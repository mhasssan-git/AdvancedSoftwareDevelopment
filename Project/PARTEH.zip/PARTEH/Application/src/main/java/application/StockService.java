package application;

import framework.annotation.Autowired;
import framework.annotation.Service;
import framework.context.ApplicationEventPublisher;

import java.lang.reflect.InvocationTargetException;

@Service
public class StockService {
    @Autowired
    private ApplicationEventPublisher publisher;
    public void changeStockValue(String stockName, double value) throws InvocationTargetException, IllegalAccessException {
        publisher.publishEvent(new StockChangeEvent(stockName, value));
    }
}


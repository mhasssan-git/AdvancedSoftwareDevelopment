package application;

import framework.annotation.EventListener;
import framework.annotation.Service;

@Service
public class HistoryLogger {
    @EventListener
    public void log(StockChangeEvent stockChangeEvent){
        System.out.printf("HistoryLogger received event: %s\n",stockChangeEvent);
    }
}

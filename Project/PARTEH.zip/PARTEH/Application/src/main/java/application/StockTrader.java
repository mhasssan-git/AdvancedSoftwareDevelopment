package application;

import framework.annotation.EventListener;
import framework.annotation.Service;

@Service
public class StockTrader {

    @EventListener
    public void trade(StockChangeEvent stockChangeEvent) {
        System.out.printf("StockTrader received event :%s\n" , stockChangeEvent);;
    }
}
